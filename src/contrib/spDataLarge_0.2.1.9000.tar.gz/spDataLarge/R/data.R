#' @name elevation
#' @title Elevation raster data
#' @description Elevation raster data from SRTM

"elevation"
