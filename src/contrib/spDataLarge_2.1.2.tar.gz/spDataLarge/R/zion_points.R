#' Point vector data
#'
#' Dataset containing 30 randomly located points in the Zion National Park
#'
#' @format A sf object
#'
"zion_points"
